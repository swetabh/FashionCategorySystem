package com;

import static org.springframework.boot.SpringApplication.run;

import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FashionCategoryApplication { 

	public static void main(String[] args) { 
		run(FashionCategoryApplication.class, args);
	}

}