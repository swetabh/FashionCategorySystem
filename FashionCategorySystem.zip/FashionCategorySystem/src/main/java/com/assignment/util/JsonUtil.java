package com.assignment.util;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * The Class JsonUtil.
 */
public final class JsonUtil { 

	/**
	 * Private Default constructor to prevent initialization from this class.
	 */
	private JsonUtil() {
	}

	private static final ObjectMapper objectMapper;

	static { 
		final ObjectMapper mapper = new ObjectMapper();
		objectMapper = mapper;
	}

	/**
	 * Object with JSON with pretty print feature.
	 *
	 * @param object the object
	 * @param pretty the pretty
	 * @return the string
	 */
	public static String toJson(final Object object, final boolean pretty) throws JsonProcessingException {
		return pretty ? objectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(object)
				: objectMapper.writeValueAsString(object);
	}

	/**
	 * Object from JSON.
	 *
	 * @param <T>          the generic type
	 * @param <R>          the generic type
	 * @param json         the json
	 * @param responseType the response type
	 * @return the r
	 */
	@SuppressWarnings("rawtypes")
	public static <T, R> R fromJson(final T json, final Class<R> responseType) throws JsonProcessingException {
		if (json instanceof String) {
			return objectMapper.readValue((String) json, responseType);
		}
		return null;
	}

}