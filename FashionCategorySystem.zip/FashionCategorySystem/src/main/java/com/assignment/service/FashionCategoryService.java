package com.assignment.service;

import static java.util.stream.Collectors.toList;
import static org.slf4j.LoggerFactory.getLogger;

import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.assignment.dao.FashionCategoryDAO;
import com.assignment.dto.CustomerTypeDTO;
import com.assignment.dto.FashionCategoryDTO;
import com.assignment.dto.FashionCategorySubTypesDTO;
import com.assignment.dto.FashionCategoryTypesDTO;
import com.assignment.entity.CustomerType;
import com.assignment.entity.FashionCategory;
import com.assignment.entity.FashionCategorySubTypes;
import com.assignment.entity.FashionCategoryTypes;
import com.fasterxml.jackson.core.JsonProcessingException;

@Service
public class FashionCategoryService {

	private static final Logger log = getLogger(FashionCategoryService.class);

	@Autowired
	private FashionCategoryDAO fashionCategoryDao;

	/***
	 * Get the fashion category list
	 * 
	 * @return
	 */
	@Transactional
	public List<CustomerTypeDTO> getFashionCategoryList() { 

		List<CustomerType> categoryList = fashionCategoryDao.findCategoryList();
		return transfromFashionCategoryListToDTO(categoryList);
	}

	/***
	 * Create new the fashion category data
	 * 
	 * @return
	 * @throws JsonProcessingException
	 */
	@Transactional
	public String createFashionCategory(CustomerTypeDTO request) {

		String categoryName = request.getName();
		CustomerType customer = fashionCategoryDao.findCategoryByName(categoryName);
		if (customer != null) {
			log.error("Category with name {} already exists", categoryName);
			return "Category with name " + categoryName + " already exists. Please try updation or insert new data";
		}
		customer = parseFashionCategoryListToEntity(request, null);
		fashionCategoryDao.saveCategory(customer);
		return "New Category by name " + categoryName + " created successfully";
	}

	/***
	 * Update the fashion category data
	 * param request
	 * 
	 * @return
	 * @throws JsonProcessingException
	 */
	@Transactional
	public String updateFashionCategory(CustomerTypeDTO request) {

		String categoryName = request.getName();
		CustomerType customer = fashionCategoryDao.findCategoryByName(categoryName);
		if (customer == null) {
			log.error("Category with name {} does not exist", categoryName);
			return "Category with name " + categoryName + " does not exist";
		}
		parseFashionCategoryListToEntity(request, customer);
		fashionCategoryDao.saveCategory(customer);
		return "Category by name " + categoryName + " updated successfully";
	}

	/***
	 * Delete the fashion category by ID
	 * @param categoryId
	 * @return
	 */
	@Transactional
	public String deleteFashionCategoryByID(long categoryId) {

		try {
			CustomerType customer = fashionCategoryDao.findCategoryById(categoryId);
			if (customer == null) { 
				log.error("Category with id {} is not available for deletion", categoryId);
				return "Category with id " + categoryId + " is not available for deletion ";
			}
			fashionCategoryDao.deleteByID(categoryId);
		} catch (RuntimeException ex) {
			log.error("Error while deleting category with id {}", categoryId);
			return "Error while deleting category with id " + categoryId;
		}
		return "Category with id " + categoryId + " deleted successfully";
	}

	/***
	 * Delete the fashion category by Name
	 * @param categoryName
	 * @return
	 */
	@Transactional
	public String deleteFashionCategoryByName(String categoryName) {

		try {
			CustomerType customer = fashionCategoryDao.findCategoryByName(categoryName);
			if (customer == null) {
				log.error("Category with name {} is not available for deletion", categoryName);
				return "Category with name " + categoryName + " is not available for deletion ";
			}
			fashionCategoryDao.deleteByName(categoryName);
		} catch (RuntimeException ex) {
			log.error("Error while deleting category with name {}", categoryName);
			return "Error while deleting category with name " + categoryName;
		}
		return "Category with name " + categoryName + " deleted successfully";
	}

	/***
	 * Transform the customer data to DTO for view
	 * @param categoryList
	 * @return
	 */
	private List<CustomerTypeDTO> transfromFashionCategoryListToDTO(List<CustomerType> categoryList) {
		return categoryList.stream().map(entity -> {

			CustomerTypeDTO customerTypeDTO = new CustomerTypeDTO();
			customerTypeDTO.setId(entity.getId());
			customerTypeDTO.setDescription(entity.getDescription());
			customerTypeDTO.setName(entity.getName());
			if (entity.getFashionCategory() != null) {
				customerTypeDTO.setFashionCategoryList(transfromCategoryListToDTO(entity.getFashionCategory()));
			}
			return customerTypeDTO;
		}).collect(toList());
	}

	/***
	 * Transform the fashion category data to DTO for view
	 * @param fashionCategoryList
	 * @return
	 */
	private List<FashionCategoryDTO> transfromCategoryListToDTO(List<FashionCategory> fashionCategoryList) {

		return fashionCategoryList.stream().map(entity -> {
			FashionCategoryDTO categoryDTO = new FashionCategoryDTO();
			categoryDTO.setId(entity.getId());
			categoryDTO.setName(entity.getName());
			categoryDTO.setDescription(entity.getDescription());
			if (entity.getFashionCategoryTypes() != null) {
				categoryDTO.setFashionCategoryTypes(
						transfromFashionCategoryTypeListToDTO(entity.getFashionCategoryTypes()));
			}
			return categoryDTO;
		}).collect(toList());
	}

	/***
	 * Transform the fashion category type data to DTO for view
	 * @param fashionCategoryTypeList
	 * @return
	 */
	private List<FashionCategoryTypesDTO> transfromFashionCategoryTypeListToDTO(
			List<FashionCategoryTypes> fashionCategoryTypeList) {

		return fashionCategoryTypeList.stream().map(entity -> {
			FashionCategoryTypesDTO categoryDTO = new FashionCategoryTypesDTO();
			categoryDTO.setId(entity.getId());
			categoryDTO.setName(entity.getName());
			categoryDTO.setDescription(entity.getDescription());
			if (entity.getFashionCategorySubTypes() != null) {
				categoryDTO.setFashionCategorySubTypes(
						transfromFashionCategorySubTypeListToDTO(entity.getFashionCategorySubTypes()));
			}
			return categoryDTO;
		}).collect(toList());
	}

	/***
	 * Transform the fashion category sub type data to DTO for save
	 * @param fashionCategorySubTypeList
	 * @return
	 */
	private List<FashionCategorySubTypesDTO> transfromFashionCategorySubTypeListToDTO(
			List<FashionCategorySubTypes> fashionCategorySubTypeList) {

		return fashionCategorySubTypeList.stream().map(entity -> {
			FashionCategorySubTypesDTO categoryDTO = new FashionCategorySubTypesDTO();
			categoryDTO.setId(entity.getId());
			categoryDTO.setName(entity.getName());
			categoryDTO.setDescription(entity.getDescription());
			return categoryDTO;
		}).collect(toList());
	}

	/***
	 * Parse the customer data to entity data for save or update
	 * @param category
	 * @param customer
	 * @return
	 */
	private CustomerType parseFashionCategoryListToEntity(CustomerTypeDTO category, CustomerType customer) {

		CustomerType customerType = new CustomerType();
		if (customer != null) {
			customerType = customer;
		} else {
			customerType.setCreatedDate(new Date());
		}
		customerType.setDescription(category.getDescription());
		customerType.setName(category.getName());
		customerType.setModifiedDate(new Date());
		if (category.getFashionCategoryList() != null) {
			customerType.setFashionCategory(parseCategoryListToEntity(category.getFashionCategoryList(), customerType));
		}
		return customerType;
	}

	/***
	 * Parse the fashion category data to entity data for save or update
	 * @param fashionCategoryList
	 * @param customerType
	 * @return
	 */
	private List<FashionCategory> parseCategoryListToEntity(List<FashionCategoryDTO> fashionCategoryList,
			CustomerType customerType) {

		return fashionCategoryList.stream().map(dto -> {

			FashionCategory category = new FashionCategory();
			FashionCategory fashionCategory = fashionCategoryDao.findCategoryDataByName(dto.getName());
			if (fashionCategory != null) {
				category = fashionCategory;
			} else {
				category.setCreatedDate(new Date());
			}
			category.setName(dto.getName());
			category.setDescription(dto.getDescription());
			category.setModifiedDate(new Date());
			category.setCustomerType(customerType);
			category.setFashionCategoryTypes(
					parseFashionCategoryTypeListToEntity(dto.getFashionCategoryTypes(), category));
			return category;
		}).collect(toList());
	}

	/***
	 * Parse the fashion category types data to entity data for save or update
	 * @param fashionCategoryTypeList
	 * @param fashionCategory
	 * @return
	 */
	private List<FashionCategoryTypes> parseFashionCategoryTypeListToEntity(
			List<FashionCategoryTypesDTO> fashionCategoryTypeList, FashionCategory fashionCategory) {

		return fashionCategoryTypeList.stream().map(dto -> {

			FashionCategoryTypes category = new FashionCategoryTypes();
			FashionCategoryTypes fashionCategoryType = fashionCategoryDao.findCategoryTypeByName(dto.getName());
			if (fashionCategoryType != null) {
				category = fashionCategoryType;
			} else {
				category.setCreatedDate(new Date());
			}
			category.setName(dto.getName());
			category.setDescription(dto.getDescription());
			category.setModifiedDate(new Date());
			category.setFashionCategory(fashionCategory);
			category.setFashionCategorySubTypes(
					parseFashionCategorySubTypeListToEntity(dto.getFashionCategorySubTypes(), category));
			return category;
		}).collect(toList());
	}

	/***
	 * Parse the fashion category sub types data to entity data for save or update
	 * @param fashionCategorySubTypeList
	 * @param fashionCategoryType
	 * @return
	 */
	private List<FashionCategorySubTypes> parseFashionCategorySubTypeListToEntity(
			List<FashionCategorySubTypesDTO> fashionCategorySubTypeList, FashionCategoryTypes fashionCategoryType) {

		return fashionCategorySubTypeList.stream().map(dto -> {

			FashionCategorySubTypes category = new FashionCategorySubTypes();
			FashionCategorySubTypes fashionCategorySubType = fashionCategoryDao
					.findCategorySubTypeByName(dto.getName());
			if (fashionCategorySubType != null) {
				category = fashionCategorySubType;
			} else {
				category.setCreatedDate(new Date());
			}
			category.setName(dto.getName());
			category.setModifiedDate(new Date());
			category.setDescription(dto.getDescription());
			category.setFashionCategoryType(fashionCategoryType);
			return category;
		}).collect(toList());
	}

}