package com.assignment.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.assignment.entity.FashionCategoryTypes;

@Repository
public interface FashionCategoryTypeRepository
		extends JpaRepository<FashionCategoryTypes, Long>, CrudRepository<FashionCategoryTypes, Long> {

	FashionCategoryTypes findById(long id);

	FashionCategoryTypes findByName(String categoryName);
}