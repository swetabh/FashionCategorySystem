package com.assignment.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.assignment.entity.CustomerType;
import com.assignment.entity.FashionCategory;
import com.assignment.entity.FashionCategorySubTypes;
import com.assignment.entity.FashionCategoryTypes;
import com.assignment.repository.CustomerTypeRepository;
import com.assignment.repository.FashionCategoryRepository;
import com.assignment.repository.FashionCategorySubTypeRepository;
import com.assignment.repository.FashionCategoryTypeRepository;

/**
 * The Class FashionCategoryDAO for all the database calls.
 */
@Component
public class FashionCategoryDAO {

	@Autowired
    private CustomerTypeRepository customerTypeRepository;

	@Autowired
    private FashionCategoryRepository categoryRepository;
	
	@Autowired
    private FashionCategoryTypeRepository categoryTypeRepository;
	
	@Autowired
    private FashionCategorySubTypeRepository categorySubTypeRepository;
	
	/***
	 * Find all the categories
	 * @param id
	 * @return
	 */
	@Transactional(readOnly = true)
	public List<CustomerType> findCategoryList() {
		return customerTypeRepository.findAll();
	}
	
	/***
	 * Find the category by id
	 * @param categoryId
	 * @return
	 */
	@Transactional(readOnly = true)
	public CustomerType findCategoryById(Long categoryId) {
		return customerTypeRepository.findById(categoryId.longValue());
	}

	/***
	 * Find the customer type by name
	 * @param categoryName
	 * @return
	 */
	@Transactional(readOnly = true)
	public CustomerType findCategoryByName(String categoryName) {
		return customerTypeRepository.findByName(categoryName);
	}
	
	/***
	 * Find the category by name
	 * @param categoryName
	 * @return
	 */
	@Transactional(readOnly = true)
	public FashionCategory findCategoryDataByName(String categoryName) {
		return categoryRepository.findByName(categoryName);
	}
	
	/***
	 * Find the category type by name
	 * @param categoryName
	 * @return
	 */
	@Transactional(readOnly = true)
	public FashionCategoryTypes findCategoryTypeByName(String categoryName) {
		return categoryTypeRepository.findByName(categoryName);
	}
	
	/***
	 * Find the category sub type by name
	 * @param categoryName
	 * @return
	 */
	@Transactional(readOnly = true)
	public FashionCategorySubTypes findCategorySubTypeByName(String categoryName) {
		return categorySubTypeRepository.findByName(categoryName);
	}
	
	/***
	 * Save or update category
	 * @param customer
	 * @return
	 */
	@Transactional
	public CustomerType saveCategory(CustomerType customer) {
		return customerTypeRepository.save(customer);
	}
	
	/***
	 * Delete existing category by ID
	 * @param categoryId
	 * @return
	 */
	@Transactional
	public void deleteByID(long categoryId) {
		customerTypeRepository.deleteById(categoryId);
	}
	
	/***
	 * Delete existing category by Name
	 * @param categoryName
	 * @return
	 */
	@Transactional
	public void deleteByName(String categoryName) {
		customerTypeRepository.deleteByName(categoryName);
	}

}