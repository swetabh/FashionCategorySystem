package com.assignment.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.assignment.entity.FashionCategorySubTypes;

@Repository
public interface FashionCategorySubTypeRepository
		extends JpaRepository<FashionCategorySubTypes, Long>, CrudRepository<FashionCategorySubTypes, Long> {

	FashionCategorySubTypes findById(long id);
	
	FashionCategorySubTypes findByName(String categoryName);
}