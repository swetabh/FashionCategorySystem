package com.assignment.dto;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class CustomerTypeDTO implements Serializable {

	private static final long serialVersionUID = 1L;

	private long id;

	private String name;

	private String description;

	private Date createdDate;

	private Date modifiedDate;

	private List<FashionCategoryDTO> fashionCategoryList;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public Date getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public List<FashionCategoryDTO> getFashionCategoryList() {
		return fashionCategoryList;
	}

	public void setFashionCategoryList(List<FashionCategoryDTO> fashionCategoryList) {
		this.fashionCategoryList = fashionCategoryList;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("CustomerTypeDTO [id=").append(id).append(", name=").append(name).append(", description=")
				.append(description).append(", createdDate=").append(createdDate).append(", modifiedDate=")
				.append(modifiedDate).append(", fashionCategoryList=").append(fashionCategoryList).append("]");
		return builder.toString();
	}

}