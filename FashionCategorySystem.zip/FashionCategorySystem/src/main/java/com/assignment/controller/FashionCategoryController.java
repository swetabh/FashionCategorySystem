package com.assignment.controller;

import static com.assignment.util.JsonUtil.toJson;
import static org.slf4j.LoggerFactory.getLogger;
import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

import java.util.List;

import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.assignment.dto.CustomerTypeDTO;
import com.assignment.service.FashionCategoryService;
import com.fasterxml.jackson.core.JsonProcessingException;

@RestController
@RequestMapping(path = "/api/fashion/category", produces = APPLICATION_JSON_VALUE)
public class FashionCategoryController { 

	private static final Logger log = getLogger(FashionCategoryController.class);

	@Autowired
	private FashionCategoryService fashionService;

	/***
	 * Get the fashion categories list
	 * 
	 * @return the category in json format
	 * @throws JsonProcessingException
	 */
	@GetMapping(path = "/list") 
	public String getFashionCategoryList() throws JsonProcessingException {

		log.info("list api called");
		List<CustomerTypeDTO> categoryList = fashionService.getFashionCategoryList();
		String response = toJson(categoryList, false);
		log.info("The fashion categories response is : {}", response);
		return response;
	}

	/***
	 * Create a new fashion category
	 * @return 
	 * @throws JsonProcessingException
	 */
	@PostMapping(path = "/create")
	public String createCategory(@RequestBody CustomerTypeDTO request) {

		log.info("create api called for request {}", request);
		return fashionService.createFashionCategory(request);
	}

	/***
	 * Create a new fashion category
	 * @return 
	 * @throws JsonProcessingException
	 */
	@PostMapping(path = "/update")
	public String updateCategory(@RequestBody CustomerTypeDTO request) {

		log.info("update api called for request {}", request);
		return fashionService.updateFashionCategory(request);
	}
	
	/***
	 * Delete the fashion category by category ID
	 * @param categoryId
	 * @return
	 */
	@DeleteMapping(path = "/deletebyid/{categoryId}")
	public String deleteCategory(@PathVariable("categoryId") Long categoryId) {

		log.info("deletebyid api called for category {}", categoryId);
		return fashionService.deleteFashionCategoryByID(categoryId);
	}

	/***
	 * Delete the fashion category by category name
	 * @param categoryName
	 * @return
	 */
	@DeleteMapping(path = "/deletebyname/{categoryName}")
	public String deleteCategory(@PathVariable("categoryName") String categoryName) {

		log.info("deletebyname api called for category {}", categoryName);
		return fashionService.deleteFashionCategoryByName(categoryName);
	}

}