CREATE TABLE [dbo].[Customer_Type](
    [id] [int] IDENTITY(1,1) NOT NULL,
    [name] [nvarchar] (20) NOT NULL,
    [description] [nvarchar] (100) NOT NULL,
    [created_date] [datetime] NOT NULL,
    [modified_date] [datetime] NOT NULL
 CONSTRAINT [PK_Customer_Type] PRIMARY KEY CLUSTERED 
(
    [id] ASC
));
        
        
CREATE TABLE [dbo].[Fashion_Category](
    [id] [int] IDENTITY(1,1) NOT NULL,
    [customer_id] [int] NOT NULL,
    [name] [nvarchar] (20) NOT NULL,
    [description] [nvarchar] (100) NOT NULL,
    [created_date] [datetime] NOT NULL,
    [modified_date] [datetime] NOT NULL
 CONSTRAINT [PK_Fashion_Category] PRIMARY KEY CLUSTERED 
(
    [id] ASC
));
        
CREATE TABLE [dbo].[Fashion_Category_Types](
    [id] [int] IDENTITY(1,1) NOT NULL,
    [category_id] [int] NOT NULL,
    [name] [nvarchar] (20) NOT NULL,
    [description] [nvarchar] (100) NOT NULL,
    [created_date] [datetime] NOT NULL,
    [modified_date] [datetime] NOT NULL
 CONSTRAINT [PK_Fashion_Category_Types] PRIMARY KEY CLUSTERED 
(
    [id] ASC
));

CREATE TABLE [dbo].[Fashion_Category_Sub_Types](
    [id] [int] IDENTITY(1,1) NOT NULL,
    [category_type_id] [int] NOT NULL,
    [name] [nvarchar] (20) NOT NULL,
    [description] [nvarchar] (100) NOT NULL,
    [created_date] [datetime] NOT NULL,
    [modified_date] [datetime] NOT NULL
 CONSTRAINT [PK_Fashion_Category_Sub_Types] PRIMARY KEY CLUSTERED 
(
    [id] ASC
));

ALTER TABLE Fashion_Category ADD FOREIGN KEY (customer_id) REFERENCES Customer_Type(id);
ALTER TABLE Fashion_Category_Types ADD FOREIGN KEY (category_id) REFERENCES Fashion_Category(id);
ALTER TABLE Fashion_Category_Sub_Types ADD FOREIGN KEY (category_type_id) REFERENCES Fashion_Category_Types(id);

--delete from Customer_Type;
--delete from Fashion_Category;
--delete from Fashion_Category_Types;
--delete from Fashion_Category_Sub_Types;

--select * from Customer_Type;
--select * from Fashion_Category;
--select * from Fashion_Category_Types;
--select * from Fashion_Category_Sub_Types;