package com.assignment.swagger;

import static java.util.Collections.emptyList;
import static springfox.documentation.builders.PathSelectors.any;
import static springfox.documentation.spi.DocumentationType.SWAGGER_2;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.spring.web.plugins.Docket;

/**
 * SwaggerConfig.java Purpose: Configuration class to dynamically generate
 * service APIs
 * 
 */
@Configuration
public class SwaggerConfig implements WebMvcConfigurer { 

	/**
	 * Create Docket document which is responsible to render service API on Swagger UI
	 * 
	 * @return Docket document.
	 */
	@Bean
	public Docket fashionCategoryApi() {
		return new Docket(SWAGGER_2)
				.useDefaultResponseMessages(false)
				.select()
				.apis(RequestHandlerSelectors.basePackage("com.assignment"))
				.paths(any())
				.build()
				.apiInfo(metadata())
				.forCodeGeneration(true);

	}

	/**
	 * Create default meta information for services documentation.
	 * 
	 * @return API Meta-Info
	 */
	private ApiInfo metadata() {

		return new ApiInfo("Fashion Category System API Docs", "Microservice API", "1.0", "urn:tos",
				ApiInfo.DEFAULT_CONTACT, "Apache 2.0", "http://www.apache.org/licenses/LICENSE-2.0", emptyList());
	}

}