package com.test;

import static com.assignment.util.JsonUtil.fromJson;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import com.assignment.dao.FashionCategoryDAO;
import com.assignment.dto.CustomerTypeDTO;
import com.assignment.entity.CustomerType;
import com.assignment.entity.FashionCategory;
import com.assignment.entity.FashionCategorySubTypes;
import com.assignment.entity.FashionCategoryTypes;
import com.assignment.service.FashionCategoryService;
import com.fasterxml.jackson.core.JsonProcessingException;

@RunWith(MockitoJUnitRunner.class)
public class FashionCategoryServiceTest {

	private String SAMPLE_RESPONSE = "{\n" + 
			"    \"id\": 11,\n" +
			"    \"name\": \"Women\",\n" + 
			"    \"description\": \"Women\",\n" + 
			"    \"fashionCategoryList\": [\n" + 
			"      {\n" + 
			"        \"id\": 9,\n" + 
			"        \"name\": \"Clothing\",\n" + 
			"        \"description\": \"Clothing\",\n" + 
			"        \"fashionCategoryTypes\": [\n" + 
			"          {\n" + 
			"            \"id\": 4,\n" + 
			"            \"name\": \"Dress\",\n" + 
			"            \"description\": \"Dress\",\n" + 
			"            \"fashionCategorySubTypes\": [\n" + 
			"              {\n" + 
			"                \"id\": 4,\n" + 
			"                \"name\": \"Causal Dresses\",\n" + 
			"                \"description\": \"Causal Dresses\"\n" + 
			"              }\n" + 
			"            ]\n" + 
			"          }\n" + 
			"        ]\n" + 
			"      }\n" + 
			"    ]\n" + 
			"}";
	
	@InjectMocks
	private FashionCategoryService fashionService;

	@Mock
	private FashionCategoryDAO fashionCategoryDao;

	@Before
	public void setMocks() throws Exception {
	}

	@Test
	public void testGetFashionCategoryListEmpty() {

		List<CustomerTypeDTO> response = fashionService.getFashionCategoryList();
		assertNotNull(response);
		assertEquals(0, response.size());
	}

	@Test
	public void testGetFashionCategoryListSuccess() throws JsonProcessingException {

		CustomerType customerType = new CustomerType();
		FashionCategory category = new FashionCategory();
		List<FashionCategory> fashionCategory = new ArrayList<>();
		category.setName("Category");
		FashionCategoryTypes categoryType = new FashionCategoryTypes();
		categoryType.setName("Category Type");
		List<FashionCategoryTypes> fashionCategoryTypes = new ArrayList<>();
		fashionCategoryTypes.add(categoryType);
		FashionCategorySubTypes fashionCategorySubType = new FashionCategorySubTypes();
		fashionCategorySubType.setName("Category Sub Type");
		List<FashionCategorySubTypes> fashionCategorySubTypes = new ArrayList<>();
		fashionCategorySubTypes.add(fashionCategorySubType);
		customerType.setName("Test");
		List<CustomerType> responseList = new ArrayList<>();
		responseList.add(customerType);
		category.setFashionCategoryTypes(fashionCategoryTypes);
		fashionCategory.add(category);
		customerType.setFashionCategory(fashionCategory);
		categoryType.setFashionCategorySubTypes(fashionCategorySubTypes);
		when(fashionCategoryDao.findCategoryList()).thenReturn(responseList);
		List<CustomerTypeDTO> response = fashionService.getFashionCategoryList();
		assertNotNull(response);
		assertEquals(1, response.size());
	}

	@Test
	public void testCreateFashionCategoryFailure() {

		CustomerTypeDTO request = new CustomerTypeDTO();
		String result = "Category with name Test already exists. Please try updation or insert new data";
		when(fashionCategoryDao.findCategoryByName(Mockito.anyString())).thenReturn(new CustomerType());
		request.setName("Test");
		String response = fashionService.createFashionCategory(request);
		assertNotNull(response);
		assertEquals(result, response);
	}

	@Test
	public void testCreateFashionCategorySuccess() throws JsonProcessingException {

		CustomerTypeDTO request = fromJson(SAMPLE_RESPONSE, CustomerTypeDTO.class);
		String response = fashionService.createFashionCategory(request);
		assertNotNull(response);
		assertEquals("New Category by name Women created successfully", response);
	}

	@Test
	public void testUpdateFashionCategoryError() throws JsonProcessingException {

		CustomerTypeDTO request = fromJson(SAMPLE_RESPONSE, CustomerTypeDTO.class);
		String result = "Category with name Women does not exist";
		when(fashionCategoryDao.findCategoryByName(Mockito.anyString())).thenReturn(null);
		String response = fashionService.updateFashionCategory(request);
		assertNotNull(response);
		assertEquals(result, response);
	}

	@Test
	public void testUpdateFashionCategorySuccess() throws JsonProcessingException {

		CustomerTypeDTO request = fromJson(SAMPLE_RESPONSE, CustomerTypeDTO.class);
		String result = "Category by name Women updated successfully";
		when(fashionCategoryDao.findCategoryByName(Mockito.anyString())).thenReturn(new CustomerType());
		String response = fashionService.updateFashionCategory(request);
		assertNotNull(response);
		assertEquals(result, response);
	}

	@Test
	public void testDeleteFashionCategoryByIDError() {

		String response = fashionService.deleteFashionCategoryByID(1);
		assertNotNull(response);
		assertEquals("Category with id 1 is not available for deletion ", response);
	}

	@Test
	public void testDeleteFashionCategoryByIDSuccess() throws JsonProcessingException {

		when(fashionCategoryDao.findCategoryById(Mockito.any())).thenReturn(new CustomerType());
		String response = fashionService.deleteFashionCategoryByID(1);
		assertNotNull(response);
		assertEquals("Category with id 1 deleted successfully", response);
	}

	@Test
	public void testDeleteFashionCategoryByNameError() {

		String response = fashionService.deleteFashionCategoryByName("test");
		assertNotNull(response);
		assertEquals("Category with name test is not available for deletion ", response);
	}

	@Test
	public void testDeleteFashionCategoryByNameSuccess() throws JsonProcessingException {

		when(fashionCategoryDao.findCategoryByName(Mockito.any())).thenReturn(new CustomerType());
		String response = fashionService.deleteFashionCategoryByName("test");
		assertNotNull(response);
		assertEquals("Category with name test deleted successfully", response);
	}
	
}