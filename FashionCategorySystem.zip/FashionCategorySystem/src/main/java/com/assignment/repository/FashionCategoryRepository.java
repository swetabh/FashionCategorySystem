package com.assignment.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.assignment.entity.FashionCategory;

@Repository
public interface FashionCategoryRepository
		extends JpaRepository<FashionCategory, Long>, CrudRepository<FashionCategory, Long> {

	FashionCategory findById(long id);

	FashionCategory findByName(String categoryName);
}