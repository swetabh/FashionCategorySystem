package com.assignment.entity;

import static javax.persistence.CascadeType.ALL;
import static javax.persistence.GenerationType.IDENTITY;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

/**
 * The persistent class for the "fashion_category_types" database table.
 * 
 */
@Entity
@Table(name = "fashion_category_types")
public class FashionCategoryTypes implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = IDENTITY)
	@Column(name = "id")
	private long id;

	@Column(name = "name")
	private String name;

	@Column(name = "description")
	private String description;

	@Column(name = "created_date")
	private Date createdDate;

	@Column(name = "modified_date")
	private Date modifiedDate;

	@ManyToOne
	@JoinColumn(name = "category_id")
	private FashionCategory fashionCategory;

	@JsonIgnore
	@OneToMany(mappedBy = "fashionCategoryType", cascade = ALL)
	private List<FashionCategorySubTypes> fashionCategorySubTypes;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public Date getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public FashionCategory getFashionCategory() {
		return fashionCategory;
	}

	public void setFashionCategory(FashionCategory fashionCategory) {
		this.fashionCategory = fashionCategory;
	}

	public List<FashionCategorySubTypes> getFashionCategorySubTypes() {
		return fashionCategorySubTypes;
	}

	public void setFashionCategorySubTypes(List<FashionCategorySubTypes> fashionCategorySubTypes) {
		this.fashionCategorySubTypes = fashionCategorySubTypes;
	}

}