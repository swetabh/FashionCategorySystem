package com.assignment.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.assignment.entity.CustomerType;

@Repository
public interface CustomerTypeRepository extends JpaRepository<CustomerType, Long>, CrudRepository<CustomerType, Long> {

	CustomerType findById(long id);
	
	CustomerType findByName(String categoryName);

	void deleteByName(String categoryName);
}